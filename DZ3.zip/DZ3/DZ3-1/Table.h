#pragma once
#include <utility>
#include <iostream>


using namespace std;

struct Point {
	int a, b;
	char c;

	Point(int a, int b, int c) {
		this->a = a;
		this->b = b;
		this->c = c;
	}



	pair<int, int> distance(Point b) {
		pair<int, int> p;
		p.first = b.a - this->a;
		p.second = b.b - this->b;
		return p;
	}

};

class Table
{
private:
	char array[20][40];

public:
	Table(Point starting_point, Point ending_point);
	void print();
	bool is_empty(int i, int j);
	char get_char(int i, int j);
	void set_array(int i, int j, char value);
	
};

