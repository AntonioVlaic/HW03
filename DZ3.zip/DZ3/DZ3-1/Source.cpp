#include <iostream>
#include "Table.h"
#include <Windows.h>

using namespace std;


int main() {
	int i, j;
	cout << "A redak: ";
	cin >> i;
	cout << "A stupac: ";
	cin >> j;
	Point A(i-1, j-1, 'A');
	cout << "B redak: ";
	cin >> i;
	cout << "B stupac: ";
	cin >> j;
	Point B(i-1, j-1, 'B');
	

	Point x(A.a, A.b, 'x');
	int counter = 0;
	Table t(A, B);
	pair<int, int> distance = x.distance(B);
	cout << distance.first << " " << distance.second << endl;
	while (x.a != B.a || x.b != B.b) {

		system("CLS");
		t.set_array(x.a, x.b, x.c);
		if (counter > 0) t.set_array(A.a, A.b, 'A');

		t.print();

		Point temp = x;
		
		//X OS
		if (distance.second > 0) {
			x.b++;
		}
		else if (distance.second < 0) {
			x.b--;
		}
		//Y OS
		else if (distance.first > 0) {
			x.a++;
		} 
		else if (distance.first < 0) {
			x.a--;
		}
		




		if (x.a == B.a && x.b == B.b) {
			t.set_array(B.a, B.b, 'x');
			t.set_array(temp.a, temp.b, '-');
			Sleep(100);
			system("CLS");
			t.print();
		}

		++counter;
		t.set_array(temp.a, temp.b, '-');
		distance = x.distance(B);
		Sleep(100);
	}
	



	return 0;
}