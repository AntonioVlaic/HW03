#include "Table.h"
#include <iostream>


using namespace std;

Table::Table(Point starting_point, Point ending_point)
{
	for (int i = 0; i < 20; ++i) {
		for (int j = 0; j < 40; ++j){
			array[i][j] = '-';
			
		}
	}
	starting_point.c = 'x';
	ending_point.c = 'B';
	array[starting_point.a][starting_point.b] = starting_point.c;
	array[ending_point.a][ending_point.b] = ending_point.c;
}

void Table::print()
{
	for (int i = 0; i < 20; ++i) {
		for (int j = 0; j < 40; ++j) {
			cout << this->get_char(i, j);
			if (j == 39) cout << endl;

		}
	}
}

void Table::set_array(int i, int j, char value)
{
	this->array[i][j] = value;
}

bool Table::is_empty(int i, int j)
{
	if (this->array[i][j] == '-') return true;
	return false;
}

char Table::get_char(int i, int j)
{
	return this->array[i][j];
	
}






